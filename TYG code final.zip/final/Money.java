public class Money {
    private final double amount;
    private final String card;
    private boolean removed = false;
    private String face;

    public Money(double amount, String face,String card) {
        this.face = face;
        this.amount = amount;
        this.card = card;
    
    }
    public double getAmount() {
        return amount;
    }

    @Override
    public String toString() {
        return face;
    }

    public String getCard() {
       return card;
	   }
    

    public void remove() {
        removed = true;
        face = "X";
    }

    public boolean isRemoved() {
        return removed;
    }
}
