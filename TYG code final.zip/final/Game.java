import java.util.*;
public class Game {
    private Player player = new Player();
    private Banker banker = new Banker();
    private int a = 0;
    private int b = 6;
    private double myAmount = 0;
    private double offer = 0;
    private int turn = 1;
    private int number = 26;
    private Money[] LinkedCards; 
	int[] money = {100,200,300,1,5000,10000,40000,60000,75000,100000,250000,1000000,50,70,3,900,6,30,750,800,90,11000,3000,250,25000,4};
	
	public void Shuffle() { //to shuffle the money

        Random r = new Random();
        for (int i = 0; i < money.length - 1; i++) {
            int j = r.nextInt(money.length);
            int tmp = money[i];
            money[i] = money[j];
            money[j] = tmp;
		    }
		}
	
	 
    public void cardSetup() {
	Shuffle();
    String cards[] = { "AC", "2C", "3C", "4C", "5C",
            "6C", "7C", "8C", "9C", "10C", "JC",
            "QC", "KC", "AD", "2D", "3D", "4D", "5D","6D","7D",
		     "8D","9D","10D","JD","QD","KD"};
	    

        LinkedCards = new Money[money.length];

        for (int i = 0; i < LinkedCards.length; i++) {
            double value = money[i];
           LinkedCards[i] = new Money(value, cards[i],cards[i]);
		   
        }
		System.out.println();
    }

    public void showCards() {
	String cards[] = { "AC", "2C", "3C", "4C", "5C",
            "6C", "7C", "8C", "9C", "10C", "JC",
            "QC", "KC", "AD", "2D", "3D", "4D", "5D","6D","7D",
		     "8D","9D","10D","JD","QD","KD"};
        for (int i = 0; i < LinkedCards.length; i++) {
            System.out.print("[" + LinkedCards[i]+ "] ");
			}
        System.out.println();
    }

    public void welcome() {
        System.out.println("\t               START!                   ");
        System.out.println("\t Please Select from the Following Cards!");
        System.out.println("\t                                        ");
    }
	public Money[] getLinkedCards(){
	return LinkedCards;
	}

    public void startGame() {

        boolean gamestatus = true;
        cardSetup();
        welcome();
        showCards();

        int choice = player.nUser();
        myAmount = LinkedCards[choice].getAmount();
       (LinkedCards[choice]).remove();
        number--;

        while (gamestatus == true) {
            showCards();
            if (number == 25 || number == 19 || number == 14 || number == 10
                    || number == 7) {
                for (a = b; a > 0; a--) {
				System.out.println(" ");
				System.out.println("\t THE CARDS AVAILABLE ARE ");
				    showCards();
                    player.remove(a, LinkedCards);
                    number--;
                }
				showCards();
                b--;
                turn++;
                banker.setOffer(turn, LinkedCards, myAmount);
                offer = banker.getOffer(turn, LinkedCards, myAmount);
                gamestatus = player.gamestatus();
            } else if (number == 1) {
                player.remove(1,LinkedCards);
                gamestatus = false;
            } else {
                player.remove(1, LinkedCards);
                number--;
                banker.setOffer(turn,LinkedCards, myAmount);
                offer = banker.getOffer(turn,LinkedCards, myAmount);
                gamestatus = player.gamestatus();
            }
        }
        finishgame();
    }

    public void finishgame() {
        if (number == 1) {
            System.out.println("\tYou Rejected the Offer of Banker");
            System.out.printf("\tYour cash is R%.2f and the banker's offer is R%.2f\n",
                    myAmount, offer);
            System.out.printf("\tYou've won  R%.2f",
                    myAmount);
        } else {
            System.out.println("\tYou Accepted the offer of Banker");
            System.out.printf("\tYour cash R%.2f and the banker's offer is R%.2f\n",
                    myAmount, offer);
            System.out.printf("\tYou've won the offer of Banker: R%.2f", offer);
        }
    }
}

