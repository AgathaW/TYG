import java.util.*;

public class Player  {

    Scanner in = new Scanner(System.in);
    Banker banker = new Banker();

    public boolean gamestatus() {
        System.out.print("\tDEAL or noDEAL! [1]DEAL [2]noDEAL: ");
        int temp = in.nextInt();
        System.out.println();
        return temp != 1;
    }

   public int nUser() {
    while(true){
        System.out.print("\n\tPlease Select Your Card number!: ");
            int nUser = in.nextInt() - 1;
            if (nUser < 0 || nUser >= 26) {
                System.out.println("\tInvalid input Try again");
            } else {
                return nUser;
            }
        }
	}
    

    public int remove(int index, Money[]LinkedCards) {
        while (true) {
		     
            System.out.print("\n\t Please remove a  Card : ");			
            int nChoice = in.nextInt() - 1;
            if (nChoice < 0 || nChoice >= LinkedCards.length || LinkedCards[nChoice].isRemoved()) {
                System.out.println();
                System.out.println("\tInvalid Input please Try again\n");
            } else {
                System.out.println("\t The amount in "+(LinkedCards[nChoice]).getCard() + " is R" + (LinkedCards[nChoice]).getAmount() + "\n");
                LinkedCards[nChoice].remove();
				
                return nChoice;
            }
			
        }

    }
}



