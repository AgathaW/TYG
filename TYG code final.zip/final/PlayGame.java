

public class PlayGame {
  
   
    public static void main(String[] args) {
        Game tyg = new Game();
        tyg.startGame();
	
	
	}
}