import java.util.*;
public class Game {
    private Player player = new Player();
    private Banker banker = new Banker();
    private int a = 0;
    private int b = 6;
    private double myAmount = 0;
    private double offer = 0;
    private int turn = 1;
    private int cases = 26;
    private List<Money> LinkedCards; 
	private String cards[] = { "Card1", "Card2", "Card3", "Card4", "Card4",
            "Card6", "Card7", "Card8", "Card9", "Card10", "Card11",
            "Card12", "Card13", "Card14", "Card15", "Card16", "Card17", "Card18","Card19","Card20",
		     "Card21","Card22","Card23","Card24","Card25","Card26"};

    public void cardSetup() {
       /* String cards[] = { "Card1", "Card2", "Card3", "Card4", "Card5",
            "Card6", "Card7", "Card8", "Card9", "Card10", "Card11",
            "Card12", "Card13", "Card14", "Card15", "Card16", "Card17", "Card18","Card19","Card20",
		     "Card21","Card22","Card23","Card24","Card25","Card26"};*/

        List<Integer> money = Arrays.asList(1, 5, 10, 25, 50, 75, 100,
        200, 300, 400, 500, 750, 1000, 5000, 10000, 25000, 50000, 75000,
        100000, 300000, 400000, 500000, 750000, 1000000, 250000, 800);

        Collections.shuffle(money);

        LinkedCards = new ArrayList<>();

        for (int i = 0; i < cards.length; i++) {
            double value = money.get(i);
            LinkedCards.get(i) = new Money(value, i + 1, cards[i]);
        }
    }

    public void showMoney() {
        for (int i = 0; i < 26; i++) {
            System.out.print("\t[" + LinkedCards.get(i)+ "]");
            if (i % 5 == 4) {
                System.out.println();
            }
        }
        System.out.println();
    }

    public void welcomeMessage() {
        System.out.println("\t~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*");
        System.out.println("\t~*               Welcome !          ~*");
        System.out.println("\t~*~*~*~*~* Hosted by Kyel David ~*~*~*~*~*~*");
        System.out.println("\t~* Please Select from the Following Cards!~*");
        System.out.println("\t~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*");
    }

    public void startGame() {

        boolean gamestatus = true;
        cardSetup();
        welcomeMessage();
        showMoney();

        int choice = player.nUser();
        myAmount = LinkedCards.get(choice).getAmount();
       ( LinkedCards.get(choice)).remove();
        cases--;

        while (gamestatus == true) {
            showMoney();
            if (cases == 25 || cases == 19 || cases == 14 || cases == 10
                    || cases == 7) {
                for (a = b; a > 0; a--) {
                    player.remove(a, LinkedCards);
                    cases--;
                }
                b--;
                turn++;
                banker.setOffer(turn, LinkedCards, myAmount);
                offer = banker.getOffer(turn, LinkedCards, myAmount);
                gamestatus = player.gamestatus();
            } else if (cases == 1) {
                player.remove(1,LinkedCards);
                gamestatus = false;
            } else {
                player.remove(1, LinkedCards);
                cases--;
                banker.setOffer(turn,LinkedCards, myAmount);
                offer = banker.getOffer(turn,LinkedCards, myAmount);
                gamestatus = player.gamestatus();
            }
        }
        finishgame();
    }

    public void finishgame() {
        if (cases == 1) {
            System.out.println("\tYou Rejected the Offer of Banker");
            System.out.printf("\tYour cash is R%.2f and the banker's offer is R%.2f\n",
                    myAmount, offer);
            System.out.printf("\tYou've won  R%.2f",
                    myAmount);
        } else {
            System.out.println("\tYou Accepted the offer of Banker");
            System.out.printf("\tYour cash R%.2f and the banker's offer is R%.2f\n",
                    myAmount, offer);
            System.out.printf("\tYou've won the offer of Banker: R%.2f", offer);
        }
    }
}

