import java.util.Scanner;

public class Player {

    Scanner in = new Scanner(System.in);
    Banker banker = new Banker();

    public boolean gamestatus() {
        System.out.print("\tDEAL or noDEAL! [1]DEAL [2]noDEAL: ");
        int temp = in.nextInt();
        System.out.println();
        return temp != 1;
    }

    public String nUser() {
        while (true) {
            System.out.print("\n\tPlease Select Your Card!: ");
            String nUser = in.nextLine();
           // if (!) {
              //  System.out.println("\tInvalid input Try again");
           /* } else {
                return nUser;
            //}*/
        }
    }

    public int remove(int index, List<Money> LinkedCards) {
        while (true) {
            System.out.print("\tPlease remove " + index + " case/s: "); 
            int nChoice = in.nextInt() - 1;
            if (nChoice < 0 || nChoice >= LinkedCards.length || LinkedCards.get(nChoice).isRemoved()) {
                System.out.println();
                System.out.println("\tInvalid Input please Try again\n");
            } else {
                System.out.println("\tyour card is "+(LinkedCards.get(nChoice)).getCard() + " " + (nChoice+1));
                System.out.println( nChoice + "is R" + (LinkedCards.get(nChoice)).getAmount() + "\n");
                LinkedCards.get(nChoice).remove();
                return nChoice;
            }
        }
    }
}



